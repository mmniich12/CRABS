close all;
clear;
clc;


port = GetPort('10.0.1.5');

function port = GetPort(ipAddress)
    % Get an available port number for communication with the specified IP address.
    range = (138:1:200);
    port = [];
    for i = range
        try
            t = tcpip(ipAddress, i)
            fopen(t);
            fclose(t);
            port = i
            break;
        catch
            % Port is not available, continue with the next port.
        end
    end
end


