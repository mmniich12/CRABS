close all;
clear;
clc;
n= 9999;
i=1;
image = 'Crabs.png'; %trademarked Image
alarm = 'Crabs_alarm.mp3'; %Required alarm 
Total_array1 = zeros(n, 1);
Total_array2 = zeros(n, 1);
Total_array3 = zeros(n, 1);

MDA_1 = 284; % Minimum Detetactable Activity For sensor 1
MDA_2 = 274; % Minimum Detetactable Activity For sensor 2
MDA_3 = 101; % Minimum Detetactable Activity For sensor 2

Base_counts_1 =1220+MDA_1; % Baseline CPS for detetctor 1 in Lab setting
Base_counts_2 = 1081+MDA_2; % Baseline CPS for detetctor 2 in Lab setting
Base_counts_3 = 50+MDA_3; % Baseline CPS for detetctor 3 in Lab setting

SN_ratio_1 = 7.57; % Signal to noise ratio of detector 1
SD1 = 13.51;          %STD of detector 1
SN_ratio_2 = 6.91;    % Signal to noise ratio of detector 2
SD2 = 10.67;          %STD of detector 2
SN_ratio_3 = 10.59;    % Signal to noise ratio of detector 3
SD3 = 13.08;          %STD of detector 3
 
   [x,Fx] = audioread(alarm);
   alarm=audioplayer(x,Fx);

prompt = "Enter Signal-to-Noise threshold value in % (Increased Value Increases Sensitivity):";
threshold = input(prompt)/100;
disp(threshold)
  
  % Define the subfolder name
  addpath('MCA1');
  addpath('MCA2');
  addpath('MCA3');


% Check if the subfolder exists
if ~isfolder('MCA3\') || ~isfolder('MCA2\') || ~isfolder('MCA1\') 
    error('Subfolders do not exist');
end



while i <=n
MCA1_txt_files = dir(fullfile('MCA1', '*.txt'));
MCA1_files = dir(fullfile('MCA1\', '*.SPE'));

MCA2_txt_files = dir(fullfile('MCA2\', '*.txt'));
MCA2_files = dir(fullfile('MCA2\', '*.SPE'));
   
% Specify the input and output file paths
inputFilePath_1 = fullfile('MCA1', sprintf('bMCA_1_%04d.SPE',i));
outputFilePath_1 = fullfile('MCA1', sprintf('bMCA_1_%04d.txt',i));
inputFilePath_2 = fullfile('MCA2',sprintf('bMCA_2_%04d.SPE',i));
outputFilePath_2 = fullfile('MCA2',sprintf('bMCA_2_%04d.txt',i));
inputFilePath_3 = fullfile('MCA3',sprintf('bMCA_3_%04d.SPE', i));
outputFilePath_3 = fullfile('MCA3',sprintf('bMCA_3_%04d.txt', i));
   

if ~isfile(inputFilePath_1) || ~isfile(inputFilePath_2) 
    disp("waiting for Spectrum files");
    continue
else
% Open the input SPE file using fopen with little-endian byte order and UTF-8 encoding
fid_1 = fopen(inputFilePath_1, 'r+', 's', 'UTF-8');
fid_2 = fopen(inputFilePath_2, 'r+', 's', 'UTF-8');
fid_3 = fopen(inputFilePath_3, 'r+', 's', 'UTF-8');

% Read the data from the file
data_1 = char(fread(fid_1, inf, 'uint8'));
data_2 = char(fread(fid_2, inf, 'uint8'));
data_3 = char(fread(fid_3, inf, 'uint8'));



% Close the input file
fclose(fid_1);
fclose(fid_2);
fclose(fid_3);

% Write the data to a tab-delimited text file
dlmwrite(outputFilePath_1, data_1, 'delimiter', '\t');
dlmwrite(outputFilePath_2, data_2, 'delimiter', '\t');
dlmwrite(outputFilePath_3, data_3, 'delimiter', '\t');



MCA_data_files_1 = fullfile('MCA1',sprintf('bMCA_1_%04d.txt',i));
MCA_data_files_2 = fullfile('MCA2',sprintf('bMCA_2_%04d.txt',i));
MCA_data_files_3 = fullfile('MCA3',sprintf('bMCA_3_%04d.txt',i));

    % Read data from files in MCA1 folder
    A = readlines(fullfile('MCA1', sprintf('bMCA_1_%04d.txt', i)));
    data = A(480:end, 1);
    output1 = process_data(data);

    % Read data from files in MCA2 folder
    A = readlines(fullfile('MCA2', sprintf('bMCA_2_%04d.txt', i)));
    data_2 = A(480:end, 1);
    output2 = process_data(data_2);

    % Read data from files in MCA3 folder
    A = readlines(fullfile('MCA3', sprintf('bMCA_3_%04d.txt', i)));
    data_3 = A(480:end, 1);
    output3 = process_data(data_3);

    % Store outputs in arrays
    Total_array1(i) = output1;
    Total_array2(i) = output2;
    Total_array3(i) = output3;


if ~isfile(MCA_data_files_1)|| ~isfile(MCA_data_files_2) || ~isfile(MCA_data_files_3)
    disp("waiting for MCA_information");
    continue
else

    Counts_data_1 = readmatrix(MCA_data_files_1);
    Counts_data_2 = readmatrix(MCA_data_files_2);
    Counts_data_3 = readmatrix(MCA_data_files_3);
    counts_1(i) = sum(Counts_data_1(160:end,1));
    counts_2(i) = sum(Counts_data_2(160:end,1));
    counts_3(i) = sum(Counts_data_3(160:end,1));
    disp("Got MCA information Continue with plotting");

    counts_stored(i,1) = Total_array1(i); % Stores the values from detetctor 1
    counts_stored(i,2) = Total_array2(i); % Stores the values from detetctor 2
    counts_stored(i,3) = Total_array3(i); % Stores the values from detetctor 3



    %Write a switch case for comparing the detetcor values here...
%    figure(1) %creates a live histogram of the counts data
%        
%         bar(1:i, counts_stored, 0.5,'b'); %plots the data in a histogram
%         set(gca,'XGrid','on', 'YGrid', 'on', 'Fontsize', 16, 'linewidth', 1)
% 
%         ylim([0 500]) %keeps the grid steady 
%         title("Crab Pot Counts");
%         ylabel("counts");
%         xlabel("time (seconds)");
%         grid on; %Bar graph grid on
%         drawnow;
     if counts_stored(i,1) > (Base_counts_1 + Base_counts_1*threshold) && counts_stored(i,2) > (Base_counts_2 + Base_counts_2*threshold) && counts_stored(i,3) > (Base_counts_3 + Base_counts_3*threshold)
            theta = linspace(0,2*pi,60);
             cmap = flipud(hot(256));
             ratio_1 = 1-(Base_counts_1/counts_stored(i,1));
    color_idx = round((ratio_1 * 255) + 1);
    color = cmap(color_idx,:);
    disp("Danger! Counts Above threshold")
  
    play(alarm);
    pause(0.5)
    stop(alarm)
     else
        
        if counts_stored(i,1)> (Base_counts_1 + Base_counts_1*threshold) && counts_stored(i,2)> (Base_counts_2 + Base_counts_2*threshold)
            theta = linspace((pi/2),(-4*pi/6),60);
             cmap = flipud(hot(256));
               ratio_1 = 1-(Base_counts_1/counts_stored(i,1)) ;
    color_idx = round((ratio_1 * 255) + 1);
    color = cmap(color_idx,:);
    disp("Danger! Counts Above threshold")
  
    play(alarm);
    pause(0.5)
    stop(alarm)
        elseif counts_stored(i,1)> (Base_counts_1 + Base_counts_1*threshold) && counts_stored(i,3)> (Base_counts_3 + Base_counts_3*threshold)
           
            theta = linspace((pi/2),(3*pi/2),60);
             cmap = flipud(hot(256));
               ratio_1 = 1-(Base_counts_1/counts_stored(i,1)) ;
    color_idx = round((ratio_1 * 255) + 1);
    color = cmap(color_idx,:);
    disp("Danger! Counts Above threshold")
  
    play(alarm);
    pause(0.5)
    stop(alarm)
        else
if counts_stored(i,1)> (Base_counts_1 + Base_counts_1*threshold)
    theta = linspace(-(pi/6),(pi/2),60);
 
    cmap = flipud(hot(256));
               ratio_1 = 1-(Base_counts_1/counts_stored(i,1)) ;
    color_idx = round((ratio_1 * 255) + 1);
    color = cmap(color_idx,:);
    disp("Danger! Counts Above threshold")
  
    play(alarm);
    pause(0.5)
    stop(alarm)
elseif counts_stored(i,3)> (Base_counts_3 + Base_counts_3*threshold)
    theta = linspace((pi/2),(7*pi/6),60);
 
    cmap = flipud(hot(256));
                ratio_1 =  1-(Base_counts_3/counts_stored(i,3));
    color_idx = round((ratio_1 * 255) + 1);
    color = cmap(color_idx,:);
    disp("Danger! Counts Above threshold")
  
    play(alarm);
    pause(0.5)
    stop(alarm)
    elseif counts_stored(i,2)> (Base_counts_2 + Base_counts_2*threshold)
    theta = linspace((7*pi/6),(5.76),60);
 
    cmap = flipud(hot(256));
                ratio_1 = 1-(Base_counts_2/counts_stored(i,2));
    color_idx = round((ratio_1 * 255) + 1);
    color = cmap(color_idx,:);
    disp("Danger! Counts Above threshold")
  
    play(alarm);
    pause(0.5)
    stop(alarm)
else
     theta = linspace(0,2*pi,180);
     color = 'green';
     disp("No threats detetcted")
     ratio_1 = 1;
     
end
        end
     end
     figure(2)  
     
rho = 7*ones(size(theta));
subplot(1, 2, 1);
p = polarplot(theta,rho); rlim([0,15]);
polarfill(gca,theta,rho-normrnd(2,0.2,size(rho)),rho+normrnd(2,0.2,size(rho)),color,0.6)
% Define the colorbar and its label
cbar = colorbar('Location', 'westoutside', 'colormap', flipud(hot), 'Position', [0.05 0.1 0.05 0.8]);
cbar.Label.String = 'CPS % Greater Than Background';
% Set the range of the colorbar to be between 0 and 100
caxis([0 1]);

subplot(1, 2, 2);
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
rgbImage = imread(image);
imshow(rgbImage);
    drawnow;
end


i=i+1;

end

end

function [output] = process_data(data)
    % Initialize output variables
    output = zeros(size(data, 1), 1);
    output_2 = strings(size(data, 1), 1);

    % Loop over rows of data
    for j = 1:size(data, 1)-1 % Use size(data, 1)-1 to avoid index out of bounds error
        % Check if next column is empty
        if data(j+1, 1) == " "
            % Skip row
            continue;
        else
            % Concatenate strings horizontally
            concatenated_string = strcat(data{j, 1}, data{j+1, 1});
            singles_value = data{j+1, 1};

            % Store concatenated string in output matrix
            output(j, 1) = str2double(concatenated_string);
            output_2(j, 1) = singles_value;
        end
    end

    % Remove empty rows from output matrix
    output = output(~isnan(output));
    output_2 = output_2(~cellfun('isempty', output_2));
    output_2 = str2double(output_2(~isnan(str2double(output_2))));

    % Compute output
    sum_single_value = sum(output_2);
    output = sum(output)-sum_single_value;
end
